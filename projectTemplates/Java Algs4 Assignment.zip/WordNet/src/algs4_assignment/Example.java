package ${IJ_BASE_PACKAGE};

/**
 * This is the Example class
 * Please put some info here.
 *
 * @author Wafer Li
 * @since 16/3/29 03:21
 */
public class Example {

}

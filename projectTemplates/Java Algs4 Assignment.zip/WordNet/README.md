\# [PROJECT_NAME]

\#\# 1. Intro

This is the detail of the assignment [NAME] [PROJECT].
Kd-Tree is a BST which aims at solving the geometric problem.

This assignment asks us to implement the 2d version, that is the **2d-Tree**

**Notice:**
To use the auto-complete I wrap the src into a package name `${IJ_BASE_PACKAGE}`;
But to submit the assignment, you need to put the src into the `default` package.

**DO REMEMBER IT!!**

\#\# 2. Solutions